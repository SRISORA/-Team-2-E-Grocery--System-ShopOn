Frontend for a basic E-commerce website developed using Angular.
<br /><br />

Features:
- Trending products
- Product collections to group products under a category
- Products in a collection with filters
- Individual product page with product images, details
- Cart, checkout
- Login, register, reset password, logout
- Account details, edit account details
- Order history
