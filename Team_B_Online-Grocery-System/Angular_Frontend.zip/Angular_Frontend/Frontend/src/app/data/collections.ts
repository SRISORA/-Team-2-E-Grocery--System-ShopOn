import { COLLECTION } from "./COLLECTION"

export const collections: COLLECTION[] = [
  {
    id: 1,
    title: 'Fruits',
    count: 100,
    img: "../../../../assets/images/collections/11.jpeg"
  },
  {
    id: 2,
    title: 'Vegetables',
    count: 200,
    img: "../../../../assets/images/collections/9.jpeg"
  },

  {
    id: 3,
    title: 'Beverages',
    count: 500,
    img: "../../../../assets/images/collections/12.jpg"
  },
  {
    id: 4,
    title: 'Snacks',
    count: 400,
    img: "../../../../assets/images/collections/13.jpeg"
  },
  {
    id: 5,
    title: 'Cleaning & Household',
    count: 800,
    img: "../../../../assets/images/collections/8.jpg"
  },
  {
    id: 6,
    title: 'Beauty & Hygiene',
    count: 200,
    img: "../../../../assets/images/collections/10.jpeg"
  },
  {
    id: 7,
    title: 'Food Grains',
    count: 900,
    img: "../../../../assets/images/collections/15.jpg"
  },
  {
    id: 8,
    title: 'Dairy Product',
    count: 300,
    img: "../../../../assets/images/collections/14.jpeg"
  }
]