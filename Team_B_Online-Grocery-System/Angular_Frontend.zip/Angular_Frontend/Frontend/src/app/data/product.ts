import { PRODUCT_T } from "./PRODUCT_T";

export const product: PRODUCT_T = {
  id: 1,
  item: 'Fruit Bucket',
  cost: 1000,
  img1: "../../../../assets/images/product/6.jpg",
  img2: "../../../../assets/images/product/5.jpg",
  img3: "../../../../assets/images/product/7.jpeg",
  img4: "../../../../assets/images/product/8.jpeg",
}