export interface COLLECTION {
  id?: number,
  title: string,
  count: number,
  img: string
}