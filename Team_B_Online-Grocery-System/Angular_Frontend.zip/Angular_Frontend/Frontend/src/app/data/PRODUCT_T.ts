export interface PRODUCT_T {
  id?: number,
  item: string,
  cost: number,
  img1: string,
  img2: string,
  img3: string,
  img4: string
}