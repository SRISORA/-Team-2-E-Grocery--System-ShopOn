export interface TRENDING {
  id?: number,
  item: string,
  cost: number,
  img: string,
  collection: string
}