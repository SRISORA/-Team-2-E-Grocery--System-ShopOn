import { CART_T } from "./CART_T";

export const cart: CART_T[] = [
  {
    id: 1,
    item: 'Coca Cola',
    cost: 90,
    quantity: 5,
    img: "../../../../assets/images/product/9.jpeg",
  },
  {
    id: 2,
    item: 'Maggie Family Pack',
    cost: 105,
    quantity: 5,
    img: "../../../../assets/images/product/5.jpg",
  },
  {
    id: 3,
    item: 'Kellogs Chocos',
    cost: 125,
    quantity: 5,
    img: "../../../../assets/images/product/6.jpg",
  },
  {
    id: 4,
    item: 'Mango Tang',
    cost: 130,
    quantity: 5,
    img: "../../../../assets/images/product/10.jpeg",
  },
  {
    id: 5,
    item: 'Benefit Lipstick',
    cost: 1000,
    quantity: 5,
    img: "../../../../assets/images/product/11.jpeg",
  },
  {
    id: 6,
    item: 'Fruit Basket',
    cost: 1600,
    quantity: 5,
    img: "../../../../assets/images/product/7.jpeg",
  },
  {
    id: 7,
    item: 'Dry Fruits',
    cost: 2300,
    quantity: 5,
    img: "../../../../assets/images/product/8.jpeg",
  },
  {
    id: 8,
    item: 'Prill Dish Washer',
    cost: 86,
    quantity: 5,
    img: "../../../../assets/images/product/12.jpg",
  }
]