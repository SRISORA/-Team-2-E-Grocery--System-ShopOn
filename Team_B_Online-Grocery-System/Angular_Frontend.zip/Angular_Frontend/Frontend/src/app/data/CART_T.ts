export interface CART_T {
  id?: number,
  item: string,
  cost: number,
  quantity: number,
  img: string
}