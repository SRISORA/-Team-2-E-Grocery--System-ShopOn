import { TRENDING } from "./TRENDING"

export const trendings: TRENDING[] = [
  {
    id: 1,
    item: 'Coca Cola',
    cost: 90,
    img: "../../../../assets/images/trending/0.jpeg",
    collection: "Coca Cola"
  },
  {
    id: 2,
    item: 'Maggie Family Pack',
    cost: 105,
    img: "../../../../assets/images/trending/10.jpg",
    collection: "Maggie"
  },
  {
    id: 3,
    item: 'Kellogs Chocos',
    cost: 125,
    img: "../../../../assets/images/trending/11.jpg",
    collection: "Chocos"
  },
  {
    id: 4,
    item: 'Mango Tang',
    cost: 130,
    img: "../../../../assets/images/trending/12.jpeg",
    collection: "Tang"
  },
  {
    id: 5,
    item: 'Fruit Basket',
    cost: 1600,
    img: "../../../../assets/images/trending/13.jpeg",
    collection: "Fruit Baket"
  },
  {
    id: 6,
    item: 'Dry Fruits',
    cost: 2300,
    img: "../../../../assets/images/trending/14.jpeg",
    collection: "Dry Fruits"
  },
  {
    id: 7,
    item: 'Benefit Lipstick',
    cost: 250,
    img: "../../../../assets/images/trending/15.jpeg",
    collection: "Lipstick"
  },
  {
    id: 8,
    item: 'Prill Dish Washer',
    cost: 86,
    img: "../../../../assets/images/trending/16.jpg",
    collection: "Dish Washer"
  },
]