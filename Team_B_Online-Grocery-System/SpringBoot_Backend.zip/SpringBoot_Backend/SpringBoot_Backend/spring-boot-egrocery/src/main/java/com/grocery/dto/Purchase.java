package com.grocery.dto;

import lombok.Data;

import java.util.Set;

import com.grocery.entity.Address;
import com.grocery.entity.Customer;
import com.grocery.entity.Order;
import com.grocery.entity.OrderItem;

@Data
public class Purchase {

    private Customer customer;
    private Address shippingAddress;
    private Address billingAddress;
    private Order order;
    private Set<OrderItem> orderItems;

}
